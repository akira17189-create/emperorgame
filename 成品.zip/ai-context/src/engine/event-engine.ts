import { callLLMWithRetry } from './llm';
import type { GameState, PendingEvent } from './types';
import { NARRATIVE_STYLE_RULES_PROMPT } from '../data/lore-bridge';

// ---- 事件模板类型 ----
export interface EventTemplate {
  id: string;
  category: '自然灾害' | '仙道异变' | '工业事故' | '党争' | '边疆' | '民间';
  name: string;
  description: string;  // TODO: DeepSeek填充
  trigger_conditions: {
    min_year?: number;
    resource_threshold?: Partial<Record<string, { min?: number; max?: number }>>;
    probability: number; // 每年触发概率 0~1
    required_tags?: string[]; // 需要有此类政策才触发
  };
  severity: 1 | 2 | 3; // 1轻微 2中等 3严重
  choices: EventChoice[]; // 2-4个选项
}

export interface EventChoice {
  id: string;
  label: string;
  description: string;
  effects: Partial<Record<string, number>>;
  requires?: string; // 需要特定资源/知识才能解锁
}

export interface ActiveEvent {
  template: EventTemplate;
  triggered_year: number;
  narrative: string; // LLM生成的事件描述
}

// ---- 事件模板库（骨架，DeepSeek负责填充description和choices）----
export const EVENT_TEMPLATES: EventTemplate[] = [

  // === 自然灾害 ===
  {
    id: "drought", category: "自然灾害", name: "黄淮大旱", severity: 3,
    description: "TODO: DeepSeek填充（50-80字场景描述）",
    trigger_conditions: {
      probability: 0.08,
      resource_threshold: { land_fertility: { max: 0.4 } }
    },
    choices: [
      { id: "relief", label: "开仓赈灾", description: "动用储粮赈济灾民",
        effects: { food: -300, morale: +5, disaster_relief: -100 } },
      { id: "tax_exempt", label: "免除灾区赋税", description: "三年不征灾区税",
        effects: { fiscal: -200, morale: +3, faction: +5 } },
      { id: "ignore", label: "置之不理", description: "让地方自己处理",
        effects: { morale: -8, population: -500 } }
    ]
  },
  {
    id: "flood", category: "自然灾害", name: "江南水患", severity: 2,
    description: "TODO: DeepSeek填充",
    trigger_conditions: { probability: 0.06 },
    choices: [
      { id: "repair", label: "修缮堤坝", description: "调拨银两修堤",
        effects: { fiscal: -150, land_fertility: +0.05 } },
      { id: "ignore", label: "暂缓处理", description: "等明年预算",
        effects: { morale: -4, food: -150 } }
    ]
  },

  // === 仙道异变 ===
  {
    id: "omen_eclipse", category: "仙道异变", name: "日食天象", severity: 2,
    description: "TODO: DeepSeek填充",
    trigger_conditions: { probability: 0.04 },
    choices: [
      { id: "pray", label: "举行祭天大典", description: "耗时三日，费银五千两",
        effects: { fiscal: -80, morale: +4 } },
      { id: "science", label: "（穿越者）解释天文现象",
        description: "告知朝臣这是自然规律",
        requires: "modern_knowledge_science",
        effects: { morale: +2, faction: +8, eunuch: -3 } }
    ]
  },

  // === 党争 ===
  {
    id: "faction_conflict", category: "党争", name: "朝堂上书大战", severity: 2,
    description: "TODO: DeepSeek填充",
    trigger_conditions: { probability: 0.10, resource_threshold: { faction: { min: 60 } } },
    choices: [
      { id: "side_a", label: "支持清流派", description: "方直一党得势",
        effects: { faction: -15, eunuch: -5 } },
      { id: "side_b", label: "支持帝党", description: "钱谦一党得意",
        effects: { faction: -10, eunuch: +5 } },
      { id: "balance", label: "各打五十大板", description: "各罚一月俸禄",
        effects: { faction: -5, morale: -1 } }
    ]
  },

  // === 边疆 ===
  {
    id: "border_raid", category: "边疆", name: "北疆游牧扣边", severity: 2,
    description: "TODO: DeepSeek填充",
    trigger_conditions: { probability: 0.07, resource_threshold: { threat: { min: 40 } } },
    choices: [
      { id: "fight", label: "出兵征讨", description: "调边军迎击",
        effects: { military: -80, threat: -15, morale: +3, fiscal: -200 } },
      { id: "peace", label: "岁币议和", description: "每年输银万两换太平",
        effects: { threat: -20, fiscal: -100, morale: -3 } }
    ]
  },

  // === 民间 ===
  {
    id: "merchant_boom", category: "民间", name: "江南商贸繁荣", severity: 1,
    description: "TODO: DeepSeek填充（正面事件）",
    trigger_conditions: { probability: 0.05, resource_threshold: { commerce: { min: 400 } } },
    choices: [
      { id: "tax_more", label: "加征商税", description: "趁机多收一成",
        effects: { fiscal: +200, commerce: -30 } },
      { id: "encourage", label: "鼓励发展", description: "给予政策支持",
        effects: { commerce: +80, morale: +2 } }
    ]
  }

  // === 自然灾害（补全至5个）===
  {
    id: "locust", category: "自然灾害", name: "蝗灾肆虐", severity: 2,
    description: "铺天盖地的蝗虫遮蔽日光，飞过之处田野尽毁，各地县令纷纷急报，请求朝廷调拨粮食赈济。",
    trigger_conditions: { probability: 0.06, resource_threshold: { land_fertility: { max: 0.6 } } },
    choices: [
      { id: "pesticide", label: "调兵驱蝗", description: "组织军民联合灭蝗", effects: { military: -20, food: -100, morale: +3 } },
      { id: "pray", label: "祭祀天神", description: "命各地举行祈晴仪式", effects: { fiscal: -60, morale: +1 } },
      { id: "import", label: "紧急购粮", description: "从邻省调拨余粮补缺口", effects: { fiscal: -250, food: +200 } }
    ]
  },
  {
    id: "epidemic", category: "自然灾害", name: "瘟疫蔓延", severity: 3,
    description: "京城南门外出现大批面色蜡黄的流民，军医来报称南方数县已有疫病，死者逾千，请皇帝圣裁。",
    trigger_conditions: { probability: 0.05, resource_threshold: { population: { min: 10000 } } },
    choices: [
      { id: "quarantine", label: "封城隔离", description: "封锁疫区，切断传播", effects: { morale: -5, population: -200, commerce: -80 } },
      { id: "medicine", label: "广发药材", description: "从太医院调拨药材", effects: { fiscal: -180, population: +100, morale: +4 } },
      { id: "ignore", label: "秘而不宣", description: "压下消息，避免恐慌", effects: { population: -500, morale: -8, eunuch: +5 } }
    ]
  },
  {
    id: "drought_severe", category: "自然灾害", name: "连年大旱", severity: 3,
    description: "北方已连续三年降雨不足，黄河水位降至百年最低，沿岸数十万百姓断炊，流民之势已成。",
    trigger_conditions: { probability: 0.04, resource_threshold: { food: { max: 600 }, morale: { max: 50 } } },
    choices: [
      { id: "move_capital", label: "迁民就食", description: "组织北方流民南迁", effects: { food: -200, morale: -3, population: -100 } },
      { id: "pray_rain", label: "御驾祈雨", description: "皇帝亲自主持祈雨大典", effects: { fiscal: -100, morale: +6, eunuch: +3 } },
      { id: "open_granary", label: "开太仓赈济", description: "动用最后储备", effects: { food: -400, morale: +8, fiscal: -100 } }
    ]
  },

  // === 仙道异变（补全至6个）===
  {
    id: "immortal_visit", category: "仙道异变", name: "方外真人入朝", severity: 1,
    description: "一名自称百年道龄的老者出现在宫门外，声称受天命托梦前来辅佐圣主，随行七名弟子，朝臣哗然。",
    trigger_conditions: { probability: 0.05 },
    choices: [
      { id: "welcome", label: "礼遇接纳", description: "封为国师，赐观星台", effects: { morale: +5, eunuch: -3, faction: +8, fiscal: -50 } },
      { id: "test", label: "考验真伪", description: "令礼部官员测试其仙法", effects: { faction: -5 } },
      { id: "expel", label: "驱逐出境", description: "视为妖人，押出京城", effects: { morale: -2, eunuch: +3 } }
    ]
  },
  {
    id: "strange_beast", category: "仙道异变", name: "异兽出没山林", severity: 2,
    description: "边境数县接连上报，山中出现形似麒麟之巨兽，所过之处村庄牲畜尽失，百姓不敢出行。",
    trigger_conditions: { probability: 0.04 },
    choices: [
      { id: "hunt", label: "遣将围猎", description: "调边军入山围剿", effects: { military: -30, morale: +5, fiscal: -80 } },
      { id: "shaman", label: "请法师驱除", description: "召道士于山口设坛", effects: { fiscal: -60, morale: +3 } },
      { id: "auspicious", label: "宣告祥瑞", description: "颁旨称为天降祥兆", effects: { morale: +8, faction: -10 } }
    ]
  },
  {
    id: "alchemy_boom", category: "仙道异变", name: "炼丹之术兴起", severity: 1,
    description: "京城中炼丹之风大盛，连带多名阁臣开始修习，宫中内侍争相进献奇石异草，内阁已有数日未能批复奏折。",
    trigger_conditions: { probability: 0.06, resource_threshold: { eunuch: { min: 40 } } },
    choices: [
      { id: "ban", label: "下旨禁止", description: "明令禁止官员修道", effects: { faction: -8, morale: -2, eunuch: -10 } },
      { id: "join", label: "皇帝亲试", description: "御用炼丹炉启动", effects: { fiscal: -120, eunuch: +15, morale: -3 } },
      { id: "regulate", label: "颁布管理条例", description: "定下时间允许私下修炼", effects: { faction: +3 } }
    ]
  },
  {
    id: "sky_fire", category: "仙道异变", name: "流星坠于京郊", severity: 2,
    description: "昨夜三更，一道赤光划破夜空，轰鸣声惊动全城，钦天监连夜上奏，称此乃天下将变之兆，满朝惊惧。",
    trigger_conditions: { probability: 0.03 },
    choices: [
      { id: "confess", label: "下罪己诏", description: "向天下承认施政过失", effects: { morale: +6, faction: -5, eunuch: -5 } },
      { id: "sacrifice", label: "举行大型祭祀", description: "七日七夜祭天仪式", effects: { fiscal: -150, morale: +4 } },
      { id: "science_explain", label: "（穿越者）科学解释", description: "告知群臣这是陨石，无需惊慌", requires: "modern_knowledge_science", effects: { morale: +3, faction: +10, eunuch: -8 } }
    ]
  },

  // === 工业革命事件（补全至5个）===
  {
    id: "print_boom", category: "工业事故", name: "书坊刊印禁书", severity: 2,
    description: "京城多家书坊趁活字印刷普及之便，秘密刊印批评朝政的禁书，已在士子间流传，御史台请求严查。",
    trigger_conditions: { probability: 0.07, required_tags: ["工业"] },
    choices: [
      { id: "ban_books", label: "查封书坊", description: "锦衣卫彻查所有书坊", effects: { eunuch: +5, faction: -8, morale: -3 } },
      { id: "amnesty", label: "特赦从宽", description: "只惩主犯，余人不究", effects: { faction: +5, morale: +2 } },
      { id: "review", label: "设立审查局", description: "建立出版前审查制度", effects: { commerce: -20, faction: -3, eunuch: +3 } }
    ]
  },
  {
    id: "mine_accident", category: "工业事故", name: "矿山塌方事故", severity: 2,
    description: "江西铜矿发生大规模塌方，矿工伤亡逾百，幸存者暴动封堵官道，当地知府无力弹压，紧急请援。",
    trigger_conditions: { probability: 0.05 },
    choices: [
      { id: "relief_pay", label: "赔偿抚恤", description: "拨银两赔偿家属，整改矿场", effects: { fiscal: -200, morale: +5, commerce: +10 } },
      { id: "suppress", label: "镇压暴动", description: "调兵平息矿工骚乱", effects: { military: -20, morale: -5, fiscal: -50 } },
      { id: "investigate", label: "彻查矿主", description: "严查是否违规开采", effects: { faction: -5, fiscal: -30, morale: +3 } }
    ]
  },
  {
    id: "tech_breakthrough", category: "工业事故", name: "匠作局技术突破", severity: 1,
    description: "匠作局工匠经年研究，据报已成功仿制出西洋水力纺机，效率较人力提升五倍，内阁请示是否推广。",
    trigger_conditions: { probability: 0.05 },
    choices: [
      { id: "promote", label: "全国推广", description: "拨款建设纺织工坊", effects: { commerce: +80, fiscal: -200, morale: +3 } },
      { id: "patent", label: "皇家专营", description: "列为皇家御用产业", effects: { commerce: +40, fiscal: +100, faction: -5 } },
      { id: "ban_tech", label: "压制技术", description: "担心影响手工业者生计", effects: { morale: +2, commerce: -10 } }
    ]
  },
  {
    id: "labor_strike", category: "工业事故", name: "工匠罢工潮", severity: 2,
    description: "京城多个作坊工匠联合停工，要求减少工时、提高酬劳，官府一时不知如何应对，商贾纷纷上书告急。",
    trigger_conditions: { probability: 0.06, resource_threshold: { commerce: { min: 300 }, morale: { max: 55 } } },
    choices: [
      { id: "negotiate", label: "官府调解", description: "命户部出面协商条件", effects: { morale: +4, commerce: -20, fiscal: -50 } },
      { id: "force_work", label: "强令复工", description: "以律法强制工匠复工", effects: { morale: -6, commerce: +10, eunuch: +3 } },
      { id: "reform", label: "颁布匠户保护令", description: "正式规定最低工时待遇", effects: { morale: +6, commerce: +20, fiscal: -80, faction: -5 } }
    ]
  },

  // === 党争/宦官作乱（补全至6个）===
  {
    id: "exam_scandal", category: "党争", name: "科举舞弊大案", severity: 3,
    description: "今科殿试结束后，落榜举子联名上书，控告今科榜首系通过贿赂考官取得功名，礼部尚书请皇帝圣断。",
    trigger_conditions: { probability: 0.06, resource_threshold: { faction: { min: 50 } } },
    choices: [
      { id: "retake", label: "重开恩科", description: "宣布本科成绩作废，重新考试", effects: { morale: +5, fiscal: -100, faction: -10 } },
      { id: "punish_all", label: "严查彻办", description: "锦衣卫介入，牵连甚广", effects: { eunuch: +8, faction: -15, morale: -3 } },
      { id: "cover", label: "从轻发落", description: "只罚考官，维护榜单", effects: { faction: +5, morale: -5 } }
    ]
  },
  {
    id: "eunuch_power", category: "党争", name: "司礼监专擅朝政", severity: 3,
    description: "司礼监秉笔太监开始私自批红，数道奏折未经皇帝御览便已发出，内阁首辅联名上疏弹劾，局势剑拔弩张。",
    trigger_conditions: { probability: 0.07, resource_threshold: { eunuch: { min: 65 } } },
    choices: [
      { id: "purge_eunuch", label: "打压宦官", description: "杖责秉笔太监，收回批红权", effects: { eunuch: -20, faction: -8, morale: +4 } },
      { id: "use_eunuch", label: "顺势利用", description: "借宦官势力压制阁臣", effects: { eunuch: +10, faction: -15, morale: -5 } },
      { id: "balance", label: "各打五十大板", description: "警告双方，维持均势", effects: { faction: -5, eunuch: -5 } }
    ]
  },
  {
    id: "faction_purge", category: "党争", name: "东林清流弹劾帝党", severity: 2,
    description: "清流派官员连续数日在朝堂上弹劾帝党要员，指其收受贿赂、结党营私，朝堂已近乎瘫痪，各方翘首待命。",
    trigger_conditions: { probability: 0.08, resource_threshold: { faction: { min: 55 } } },
    choices: [
      { id: "side_clean", label: "支持清流", description: "严查帝党要员腐败", effects: { faction: -15, eunuch: -8, morale: +5 } },
      { id: "side_emperor", label: "保护帝党", description: "压制清流，维护心腹", effects: { faction: -10, eunuch: +8, morale: -4 } },
      { id: "dismiss_all", label: "廷杖各方", description: "被弹劾者降职，弹劾者也受罚", effects: { faction: -20, morale: -2, eunuch: -5 } }
    ]
  },

  // === 边疆危机（补全至5个）===
  {
    id: "pirate_raid", category: "边疆", name: "倭寇入侵沿海", severity: 2,
    description: "东南沿海数座城镇遭倭寇劫掠，浙江巡抚紧急上奏，当地卫所兵力不足，已有多处失守，商路断绝。",
    trigger_conditions: { probability: 0.06, resource_threshold: { military: { max: 2500 } } },
    choices: [
      { id: "send_troops", label: "调水师征讨", description: "抽调精锐水师入浙", effects: { military: -60, threat: -10, fiscal: -150, morale: +3 } },
      { id: "recruit", label: "招募乡勇", description: "允许地方自行募兵防卫", effects: { threat: -5, faction: +5, commerce: -30 } },
      { id: "pay_off", label: "招抚倭首", description: "许以互市之利换取停火", effects: { threat: -8, morale: -4, commerce: +40 } }
    ]
  },
  {
    id: "army_mutiny", category: "边疆", name: "边军哗变", severity: 3,
    description: "西北驻边大军因粮饷拖欠半年，三千士兵哗变，杀副将出走，宣称若朝廷再不发饷则将率众南下。",
    trigger_conditions: { probability: 0.05, resource_threshold: { military: { max: 1800 }, fiscal: { max: 3000 } } },
    choices: [
      { id: "pay_ransom", label: "紧急拨发欠饷", description: "凑足银两安抚军心", effects: { fiscal: -400, military: +30, threat: -5 } },
      { id: "negotiate", label: "派使节招抚", description: "封赏哗变首领换取归顺", effects: { faction: -8, threat: -8, military: -10 } },
      { id: "punish", label: "发兵镇压", description: "视为叛乱，武力平息", effects: { military: -100, fiscal: -200, threat: +5, morale: -5 } }
    ]
  },
  {
    id: "tribute_state", category: "边疆", name: "藩属国请求支援", severity: 2,
    description: "西南藩属小国遣使入京，称其国遭北方游牧入侵，请求靖朝发兵援助，不援则恐该国落入敌手成为威胁。",
    trigger_conditions: { probability: 0.05, resource_threshold: { threat: { min: 30 } } },
    choices: [
      { id: "aid", label: "遣兵援助", description: "出兵保护藩属", effects: { military: -80, threat: -10, fiscal: -200, faction: +5 } },
      { id: "supplies", label: "仅给物资", description: "赠送武器粮草，不出兵", effects: { fiscal: -100, threat: -3 } },
      { id: "abandon", label: "坐视不理", description: "以国力不足为由拒绝", effects: { threat: +8, morale: -3, faction: -5 } }
    ]
  },

  // === 民间异动（补全至5个）===
  {
    id: "peasant_revolt", category: "民间", name: "饥民暴动", severity: 3,
    description: "河南数县饥民在一名落第秀才带领下聚众万人，打出「均田免粮」旗号，已攻破两座县城，府兵不敌溃散。",
    trigger_conditions: { probability: 0.06, resource_threshold: { food: { max: 500 }, morale: { max: 40 } } },
    choices: [
      { id: "suppress_hard", label: "大军征剿", description: "调精锐彻底平叛", effects: { military: -100, fiscal: -300, morale: -3, threat: -5 } },
      { id: "amnesty_revolt", label: "招安首领", description: "许以官职换取投降", effects: { military: -20, faction: -10, morale: +3 } },
      { id: "reform_food", label: "开仓并减税", description: "釜底抽薪，让暴动失去民心", effects: { food: -400, fiscal: -100, morale: +8, threat: -8 } }
    ]
  },
  {
    id: "merchant_guild", category: "民间", name: "商帮势力崛起", severity: 1,
    description: "江南徽商联合闽商组成跨省商会，控制粮食与布匹集散，已有多地官员私下向商帮借贷，内阁感到忧虑。",
    trigger_conditions: { probability: 0.06, resource_threshold: { commerce: { min: 450 } } },
    choices: [
      { id: "tax_heavily", label: "重征商税", description: "打压商帮过快膨胀", effects: { commerce: -60, fiscal: +200, morale: -2 } },
      { id: "cooperate", label: "官商合作", description: "引导商帮承接官府采购", effects: { commerce: +40, fiscal: +80, faction: -5 } },
      { id: "charter", label: "颁发特许状", description: "赋予合法地位以换监管权", effects: { commerce: +60, fiscal: +50, faction: -3 } }
    ]
  },
  {
    id: "secret_society", category: "民间", name: "白莲教暗中传播", severity: 2,
    description: "锦衣卫密报，白莲教已在北方数省秘密发展教众逾万，其教义煽动贫苦百姓对抗朝廷，首领身份不明。",
    trigger_conditions: { probability: 0.05, resource_threshold: { morale: { max: 55 } } },
    choices: [
      { id: "crack_down", label: "全面清查", description: "锦衣卫大规模搜捕", effects: { eunuch: +10, morale: -4, faction: -5, threat: -8 } },
      { id: "infiltrate", label: "暗中渗透", description: "安插卧底等待时机", effects: { eunuch: +3, threat: -3 } },
      { id: "amnesty_relig", label: "颁令宽容", description: "只要不暴力，允许信仰自由", effects: { morale: +5, faction: +5, threat: +5 } }
    ]
  }

  // TODO: 可继续补充至32个
];

// ---- 核心函数 ----

/**
 * 每tick检查是否触发事件
 * 在 tick.ts 的世界模拟阶段调用
 */
export function checkEventTriggers(state: GameState): EventTemplate[] {
  const triggered: EventTemplate[] = [];
  const r = state.resources;

  for (const template of EVENT_TEMPLATES) {
    const cond = template.trigger_conditions;

    // 年份检查
    if (cond.min_year && state.world.year < cond.min_year) continue;

    // 资源阈值检查
    let resourceOk = true;
    if (cond.resource_threshold) {
      for (const [key, range] of Object.entries(cond.resource_threshold)) {
        const val = (r as any)[key] ?? 0;
        if (range.min !== undefined && val < range.min) { resourceOk = false; break; }
        if (range.max !== undefined && val > range.max) { resourceOk = false; break; }
      }
    }
    if (!resourceOk) continue;

    // 政策标签检查
    if (cond.required_tags?.length) {
      const activeTags = state.policies.active.flatMap(p => p.tags);
      if (!cond.required_tags.every(t => activeTags.includes(t))) continue;
    }

    // 同一事件当年只触发一次
    const alreadyPending = state.events.pending.some(p => p.template_id === template.id);
    if (alreadyPending) continue;

    // 概率检查（严重事件+双倍概率）
    const effectiveProb = cond.probability * (template.severity === 3 ? 1.5 : 1);
    if (Math.random() < effectiveProb) { triggered.push(template); }
  }

  return triggered;
}

/**
 * 生成事件叙事（调用LLM，可选）
 */
export async function narrateEvent(
  template: EventTemplate,
  state: GameState
): Promise<string> {
  try {
    const raw = await callLLMWithRetry({
      system: `你是靖朝皇帝游戏的事件叙述者。
${NARRATIVE_STYLE_RULES_PROMPT}
输出纯文本叙事，不超过150字，不要JSON。`,
      user: `事件：${template.name}
背景：${template.description}
当前：${state.world.dynasty}${state.world.era}${state.world.year}年，民心${state.resources.morale}，国库${state.resources.fiscal}
请用靖朝文风叙述这个事件的经过，结尾留悬念等待玩家决策。`,
      temperature: 0.8,
      tag: 'event_narration'
    });
    return raw.trim();
  } catch {
    return template.description || `${template.name}突然发生，需要陛下裁决。`;
  }
}

/**
 * 执行玩家的事件选择
 */
export function resolveEventChoice(
  state: GameState,
  templateId: string,
  choiceId: string
): { newState: GameState; narrative: string } {
  const template = EVENT_TEMPLATES.find(t => t.id === templateId);
  const choice   = template?.choices.find(c => c.id === choiceId);

  if (!template || !choice) {
    return { newState: state, narrative: '事件处理完毕。' };
  }

  // 应用资源变化
  const newState = { ...state, resources: { ...state.resources } };
  for (const [key, delta] of Object.entries(choice.effects)) {
    if (key in newState.resources) {
      (newState.resources as any)[key] = Math.max(0, ((newState.resources as any)[key] ?? 0) + delta);
    }
  }

  // 从pending移除
  newState.events = {
    ...state.events,
    pending: state.events.pending.filter(p => p.template_id !== templateId)
  };

  // 加入集体记忆
  const memory = `${state.world.year}年${template.name}（${choice.label}）`;
  newState.world = {
    ...state.world,
    collective_memory: [...state.world.world.collective_memory.slice(-19), memory]
  };

  // 党争类事件派系联动
  if (template.category === '党争') {
    // 确保factions对象存在
    if (!newState.world.factions) {
      newState.world.factions = { qingliu: 50, didang: 50, eunuch_faction: 30 };
    }

    // 根据玩家选择修改派系势力
    if (choiceId.includes('qingliu') || choice.label.includes('清流')) {
      // 支持清流
      newState.world.factions.qingliu = Math.max(0, Math.min(100, newState.world.factions.qingliu + 10));
      newState.world.factions.didang = Math.max(0, Math.min(100, newState.world.factions.didang - 8));
    } else if (choiceId.includes('didang') || choice.label.includes('帝党')) {
      // 支持帝党
      newState.world.factions.didang = Math.max(0, Math.min(100, newState.world.factions.didang + 10));
      newState.world.factions.qingliu = Math.max(0, Math.min(100, newState.world.factions.qingliu - 8));
    } else if (choiceId.includes('neutral') || choice.label.includes('各打五十大板') || choice.label.includes('中立')) {
      // 各打五十大板
      newState.world.factions.qingliu = Math.max(0, Math.min(100, newState.world.factions.qingliu - 5));
      newState.world.factions.didang = Math.max(0, Math.min(100, newState.world.factions.didang - 5));
    }
  }

  return {
    newState,
    narrative: `陛下选择「${choice.label}」。${choice.description}。`
  };
}
