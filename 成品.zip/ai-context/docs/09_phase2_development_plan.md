# Phase 2 开发计划：皇帝游戏核心循环实现

**基于用户修改意见和4个关键问题的开发计划**

**最后更新**: 2026-04-18  
**状态**: Phase 2.1 已完成  
**优先级**: P1（核心功能）

---

## 1. 当前项目状态分析

### 1.1 已实现功能（MVP阶段）
- 指令归一化系统（`normalize-command.md`）
- 角色决策系统（`role-execution.md`）
- 叙事生成系统（`narrator.ts`）
- 基础UI框架（三栏布局）
- 状态管理系统（`state.ts`）
- 类型定义系统（`types.ts`）

### 1.2 需要实现的功能（Phase 2）
- 完整的Tick系统（`tick.ts`）
- 资源变化规则
- NPC自主行为系统
- 世界状态演变
- 政策系统影响

### 1.3 当前代码问题分析
基于用户提供的4个关键问题：

1. **数值系统会"指数爆炸"**：当前公式使用乘法增长，会导致数值失控
2. **字段"全覆盖原则"实现方式错误**：强制所有字段参与每tick计算，导致系统复杂度过高
3. **NPC规则触发条件写错**：语法错误（缺少比较运算符）
4. **Tick职责过重**：单函数堆叠所有逻辑，难以维护

---

## 2. 核心原则：字段全覆盖原则（正确实现）

### 2.1 原则定义
**所有字段必须有用途，但不要求参与每tick计算**

### 2.2 字段分层（三层架构）

#### 🧠 Core层（必须参与每tick计算）
- **Resources**: food, population, fiscal, military, morale, threat
- **作用**: 影响游戏核心循环，每tick必须计算

#### 🔧 Support层（间接参与，事件触发时计算）
- **Resources**: eunuch, faction, commerce, tax_rate, military_cost, disaster_relief, agri_pop, land_fertility
- **Emperor**: age, generation, prestige
- **World**: year, weather_this_year, conflict_ratio
- **NPCState**: pressure, satisfaction, loyalty_to_emperor
- **TraitWeights**: 所有6个特质
- **作用**: 影响Core层变化，在特定条件下计算

#### 📖 Flavor层（只记录，不参与计算）
- **Emperor**: id, name, traits, knowledge, memory
- **World**: dynasty, era, tone, named_events, collective_memory, wills
- **NPCState**: recent_events, behavior_modifier
- **作用**: 记录游戏历史，提供叙事素材

### 2.3 覆盖验证表

| 字段层级 | 字段数量 | 计算频率 | 验证标准 |
|---------|---------|---------|---------|
| Core | 6个 | 每tick | 必须变化 |
| Support | 17个 | 条件触发 | 有触发条件 |
| Flavor | 20个 | 事件触发 | 能记录变化 |

---

## 3. 关键问题修复方案

### 3.1 数值系统修复：软增长 + clamp

**问题**: 当前使用乘法增长（`*1.05`），会导致指数爆炸  
**解决**: 全部改成加法变化 + 数值限制

#### 修复规则：
```typescript
// 错误示例（禁止使用）
threat = threat * 1.05 + (100 - military) * 0.1
faction = faction * (1 + eunuch * 0.005)

// 正确示例（必须使用）
threat = clamp(threat + 2 + (100 - military) * 0.05, 0, 100)
faction = clamp(faction + eunuch * 0.2, 0, 100)
```

#### 数值范围限制：
- 所有Resources字段：0-10000（根据字段特性调整）
- 所有百分比字段：0-100
- 所有比率字段：0-1

### 3.2 字段分层实现

**问题**: 强制所有字段参与每tick计算  
**解决**: 实现三层架构，不同层级不同计算频率

#### 实现方式：
```typescript
// 在tick.ts中分层实现
function executeTick(state: GameState): GameState {
  // 1. Core层：每tick必须计算
  applyCoreRules(state)
  
  // 2. Support层：条件触发
  applySupportRules(state)
  
  // 3. Flavor层：事件触发
  applyFlavorRules(state)
  
  return state
}
```

### 3.3 NPC规则语法修复

**问题**: 触发条件写错（缺少比较运算符）  
**解决**: 统一使用标准比较语法

#### 修复示例：
```typescript
// 错误示例（禁止使用）
if NPC.state.satisf 40 && NPC.traits.loyalty60

// 正确示例（必须使用）
if NPC.state.satisfaction < 40 && NPC.traits.loyalty < 60
```

### 3.4 Tick职责拆分

**问题**: 单函数堆叠所有逻辑  
**解决**: 拆分为多个子函数

#### 函数结构：
```typescript
export function executeTick(state: GameState): GameState {
  const newState = JSON.parse(JSON.stringify(state))
  
  // 时间推进
  applyTimeEvolution(newState)
  
  // 资源规则
  applyResourceRules(newState)
  
  // NPC行为
  applyNpcBehaviors(newState)
  
  // 世界演变
  applyWorldEvolution(newState)
  
  // 政策影响
  applyPolicies(newState)
  
  return newState
}
```

---

## 4. 分阶段开发计划

### 4.1 Phase 2.1：最小可运行Tick系统（3天）

**目标**: 实现最小可运行的Tick系统，数值能变化且可控

#### 必做文件：
1. **src/engine/tick.ts** - 在现有结构上补充函数
   - 不改变现有函数签名
   - 不改变GameState结构
   - 只允许新增子函数并在executeTick内串联调用
   - 实现Core层资源规则（6个字段）
   - 实现基础NPC行为（2条规则，从外部读取）
   - 实现时间推进（year, age, weather）

2. **src/engine/state.ts** - 状态管理增强
   - 添加批量更新方法
   - 添加变化日志记录
   - 添加数值验证

3. **src/engine/types.ts** - 类型扩展
   - 添加TickContext类型
   - 添加ChangeLog类型
   - 添加NPC行为规则类型

#### 验收标准：
- [ ] 执行一次tick，所有Core层字段发生变化
- [ ] 数值变化有明确原因（不是随机变化）
- [ ] 数值不会溢出（有clamp限制）
- [ ] 无报错，代码结构清晰

### 4.2 Phase 2.2：完整资源系统（2天）

**目标**: 实现所有14个Resources字段的完整计算

#### 扩展内容：
1. **tick.ts** - 完整资源规则
   - 实现所有14个Resources字段的计算
   - 实现Support层资源规则
   - 实现资源间相互影响

2. **types.ts** - 资源规则类型
   - 添加ResourceRule类型
   - 添加资源变化日志

#### 验收标准：
- [ ] 所有14个Resources字段有明确的计算规则
- [ ] 资源间有相互影响关系
- [ ] 数值变化有合理范围

### 4.3 Phase 2.3：NPC自主行为系统（3天）

**目标**: 实现NPC基于特质的自主行为

#### 扩展内容：
1. **core-characters.ts** - NPC行为框架
   - 实现可配置的行为规则框架（NPCBehaviorRule类型）
   - 只实现2条规则：loyalty高→上奏，greed高→贪腐
   - 规则从外部数据读取，不写死在代码中
   - 实现行为触发条件判断函数
   - 实现行为影响计算函数

2. **tick.ts** - NPC行为集成
   - 集成NPC行为系统
   - 实现NPC行为对Resources的影响

3. **types.ts** - NPC行为类型
   - 添加NPCBehaviorRule类型
   - 添加NPC行为日志

#### 验收标准：
- [ ] NPC基于特质触发不同行为
- [ ] NPC行为影响游戏状态
- [ ] NPC行为有明确触发条件

### 4.4 Phase 2.4：世界状态演变（2天）

**目标**: 实现世界状态的自然演变

#### 扩展内容：
1. **tick.ts** - 世界演变规则
   - 实现World字段的自然变化
   - 实现Emperor字段的时间变化
   - 实现Flavor层的记录功能

2. **types.ts** - 世界演变类型
   - 添加WorldEvolutionRule类型
   - 添加事件记录类型

#### 验收标准：
- [ ] 世界状态随时间自然变化
- [ ] 重大事件被记录到Flavor层
- [ ] 变化有明确的原因和影响

### 4.5 Phase 2.5：UI反馈系统（2天）

**目标**: 实现所有字段变化的可视化反馈

#### 扩展内容：
1. **src/ui/CourtPage.tsx** - 主界面增强（最小修改）
   - 添加Core层6个资源的数值显示
   - 添加关键Support层4个资源的数值显示（tax_rate, faction, commerce, eunuch）
   - 其他字段只记录，不展示
   - 添加简单的数值变化日志（console.log）

2. **src/ui/components/ResourcePanel.tsx** - 资源面板增强
   - 显示所有14个Resources字段
   - 显示数值变化趋势

3. **src/ui/components/NpcCard.tsx** - NPC状态显示
   - 显示NPC当前状态
   - 显示NPC行为倾向

#### 验收标准：
- [ ] 所有字段变化在UI中有反馈
- [ ] 用户能看到数值变化原因
- [ ] UI响应及时，无卡顿

---

## 5. 需要修改的文件清单

### 5.1 核心文件（必须修改）

| 文件路径 | 修改内容 | 优先级 |
|---------|---------|--------|
| `src/engine/tick.ts` | 在现有结构上补充函数，不改变函数签名和State结构 | P1 |
| `src/engine/state.ts` | 添加批量更新、变化日志、数值验证 | P1 |
| `src/engine/types.ts` | 添加TickContext、ChangeLog、行为规则类型 | P1 |
| `src/data/core-characters.ts` | 实现可配置的行为规则框架，只实现2条规则 | P1 |

### 5.2 Prompt文件（需要增强）

| 文件路径 | 修改内容 | 优先级 |
|---------|---------|--------|
| `src/prompts/normalize-command.md` | 添加指令影响映射，添加数值计算公式 | P2 |
| `src/prompts/role-execution.md` | 添加NPC对数值变化的反应逻辑 | P2 |

### 5.3 UI文件（需要增强）

| 文件路径 | 修改内容 | 优先级 |
|---------|---------|--------|
| `src/ui/CourtPage.tsx` | 添加数值变化显示、事件通知系统 | P3 |
| `src/ui/components/ResourcePanel.tsx` | 显示所有14个Resources字段 | P3 |
| `src/ui/components/NpcCard.tsx` | 显示NPC状态变化 | P3 |

### 5.4 文档文件（需要更新）

| 文件路径 | 修改内容 | 优先级 |
|---------|---------|--------|
| `docs/06_mvp_scope.md` | 添加"核心游戏循环规则"章节 | P2 |
| `docs/04_gamestate_schema.md` | 添加字段作用说明 | P3 |

---

## 6. 实施要求

### 6.1 代码质量要求
1. **函数拆分**: 每个函数不超过50行
2. **类型安全**: 所有函数必须有明确的类型定义
3. **错误处理**: 所有外部调用必须有错误处理
4. **注释完整**: 所有公共函数必须有JSDoc注释

### 6.2 测试要求
1. **单元测试**: 每个Tick规则必须有单元测试
2. **集成测试**: 完整Tick流程必须有集成测试
3. **边界测试**: 所有数值边界必须有测试

### 6.3 性能要求
1. **执行时间**: 单个tick执行时间不超过100ms
2. **内存使用**: 游戏状态对象不超过1MB
3. **UI响应**: 数值变化到UI更新不超过16ms（60fps）

---

## 7. 风险控制

### 7.1 技术风险
- **数值溢出**: 使用严格的clamp限制
- **性能问题**: 分层计算，避免不必要的计算
- **状态不一致**: 使用深拷贝确保状态不可变性

### 7.2 进度风险
- **需求变更**: 严格遵循分阶段开发
- **技术难点**: 先实现最小可运行版本
- **集成问题**: 每个阶段完成后进行集成测试

### 7.3 质量风险
- **代码质量**: 代码审查和单元测试
- **用户体验**: 每个阶段进行用户测试
- **文档完整性**: 及时更新文档

---

## 8. 验收标准

### 8.1 Phase 2.1验收标准
- [ ] 执行一次tick，Core层6个字段发生变化
- [ ] 数值变化有明确原因（不是随机变化）
- [ ] 数值不会溢出（有clamp限制）
- [ ] 无报错，代码结构清晰
- [ ] 有基本的单元测试

### 8.2 完整Phase 2验收标准
- [ ] 所有43个字段都有明确的用途
- [ ] Core层字段每tick都变化
- [ ] Support层字段有触发条件
- [ ] Flavor层字段能记录变化
- [ ] UI能显示所有字段变化
- [ ] 有完整的单元测试和集成测试
- [ ] 有完整的文档说明

---

## 9. 时间安排

### 9.1 总时间预估
- **Phase 2.1**: 3天（最小可运行Tick系统）
- **Phase 2.2**: 2天（完整资源系统）
- **Phase 2.3**: 3天（NPC自主行为系统）
- **Phase 2.4**: 2天（世界状态演变）
- **Phase 2.5**: 2天（UI反馈系统）
- **总计**: 12天

### 9.2 里程碑
1. **第3天**: 最小可运行Tick系统完成
2. **第5天**: 完整资源系统完成
3. **第8天**: NPC自主行为系统完成
4. **第10天**: 世界状态演变完成
5. **第12天**: UI反馈系统完成，完整Phase 2完成

---

## 10. 附录：字段覆盖验证表

### 10.1 Resources字段（14/14覆盖）

| 字段名 | 层级 | 计算频率 | 影响关系 |
|--------|------|---------|---------|
| food | Core | 每tick | 受agri_pop, land_fertility, population影响 |
| population | Core | 每tick | 受morale影响 |
| fiscal | Core | 每tick | 受tax_rate, population, military_cost, disaster_relief影响 |
| military | Core | 每tick | 受threat影响 |
| morale | Core | 每tick | 受tax_rate, faction影响 |
| threat | Core | 每tick | 受military影响，自然增长 |
| eunuch | Support | 条件触发 | 影响faction |
| faction | Support | 条件触发 | 受eunuch影响，影响morale |
| commerce | Support | 条件触发 | 受threat影响 |
| tax_rate | Support | 玩家指令 | 影响fiscal, morale |
| military_cost | Support | 条件触发 | 受military影响 |
| disaster_relief | Support | 事件触发 | 影响fiscal |
| agri_pop | Support | 条件触发 | 影响food |
| land_fertility | Support | 条件触发 | 受weather影响，影响food |

### 10.2 Emperor字段（8/8覆盖）

| 字段名 | 层级 | 计算频率 | 影响关系 |
|--------|------|---------|---------|
| id | Flavor | 固定 | 基础标识 |
| name | Flavor | 固定 | 基础标识 |
| age | Support | 每tick | 自动+1 |
| generation | Support | 每25年 | 自动+1 |
| prestige | Support | 条件触发 | 受NPC行为影响 |
| traits | Flavor | 固定 | 影响NPC行为 |
| knowledge | Flavor | 事件触发 | 记录重大事件 |
| memory | Flavor | 事件触发 | 记录关键事件 |

### 10.3 World字段（9/9覆盖）

| 字段名 | 层级 | 计算频率 | 影响关系 |
|--------|------|---------|---------|
| dynasty | Flavor | 固定 | 基础设定 |
| era | Flavor | 固定 | 基础设定 |
| year | Support | 每tick | 自动+1 |
| tone | Flavor | 事件触发 | 受resources和events影响 |
| named_events | Flavor | 事件触发 | 记录重大事件 |
| collective_memory | Flavor | 事件触发 | 记录集体记忆 |
| wills | Flavor | 事件触发 | 记录遗诏 |
| weather_this_year | Support | 每tick | 随机变化，影响land_fertility |
| conflict_ratio | Support | 条件触发 | 受NPC行为影响 |

### 10.4 NPCState字段（5/5覆盖）

| 字段名 | 层级 | 计算频率 | 影响关系 |
|--------|------|---------|---------|
| pressure | Support | 条件触发 | 影响NPC行为触发 |
| satisfaction | Support | 条件触发 | 影响NPC行为触发 |
| loyalty_to_emperor | Support | 条件触发 | 影响NPC行为效果 |
| recent_events | Flavor | 事件触发 | 记录NPC近期行为 |
| behavior_modifier | Flavor | 事件触发 | 记录NPC行为倾向 |

### 10.5 TraitWeights字段（6/6覆盖）

| 字段名 | 层级 | 计算频率 | 影响关系 |
|--------|------|---------|---------|
| loyalty | Support | 条件触发 | 影响NPC忠诚行为 |
| ambition | Support | 条件触发 | 影响NPC野心行为 |
| greed | Support | 条件触发 | 影响NPC贪腐行为 |
| courage | Support | 条件触发 | 影响NPC直谏行为 |
| rationality | Support | 条件触发 | 影响NPC改革行为 |
| stability | Support | 条件触发 | 影响NPC稳定行为 |

---

**文档维护者**: WPS灵犀 AI助手  
**最后更新**: 2026-04-18  
**版本**: 1.0  
**状态**: Phase 2.1 已完成
## 11. 严格限制（必须遵守）

### 11.1 不允许重写现有文件结构
- 不改 GameState 结构
- 不改函数签名
- 只允许新增函数 + 在现有流程中调用

### 11.2 tick.ts 只做"机制实现"，不做"规则定义"
- 行为规则必须可配置（不可写死）
- 所有规则通过数据结构传入

### 11.3 UI 暂不扩展（只允许最小修改）
- 不实现43字段展示
- 仅保证数值变化可被 console.log 或简单UI看到
